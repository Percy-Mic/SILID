// Real-controller traversal test.
//
// This drives the actual Player class and the actual architecture queries in
// the running Vite game. It does not teleport between floors: it puts the
// player at the foot of a staircase and walks, steering the way a player
// would, then steps off the landing and reports the floor and room reached.
// If a staircase is covered by a floor, walled off, or too steep, this
// reports the exact point where the body stopped and the height it stood at.
const { chromium } = require('playwright');

const URL = process.env.SILID_URL || 'http://127.0.0.1:5333/?probe=1';

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 960, height: 600 } });
  page.on('pageerror', (e) => console.log('PAGEERROR', e.message));
  await page.goto(URL);
  await page.waitForFunction(() => window.__silid?.ready, null, { timeout: 180000 });

  const result = await page.evaluate(() => {
    const s = window.__silid;
    const pl = s.player;
    const g = s.game;
    // This is a stair-navigation probe. The resident can catch the player
    // between flights, which disables the controller for 2.2 s and teleports
    // the body to the foyer; that is a correct game behaviour and a useless
    // measurement of whether a staircase is walkable. Stub the AI for the
    // probe only — no game code is changed by this test.
    if (g.resident) g.resident.update = () => {};
    if (g.caughtActive) { g.caughtActive = false; pl.enabled = true; }
    pl.enabled = true;
    const cx = -1.5, cz = 7.5;

    const aim = (dir) => { pl.yaw = Math.atan2(-dir.x, -dir.z); };

    const stepOnce = (dir, dt = 0.033) => {
      aim(dir);
      pl.keys.KeyW = true;
      const bx = pl.pos.x, bz = pl.pos.z;
      pl.update(dt, g);
      g.update(dt);
      return Math.hypot(pl.pos.x - bx, pl.pos.z - bz);
    };

    // walk the winder from the foot at (x,z,y) until the foot reaches `target`
    const climbTo = ({ x, z, y, target, targetR = 1.6, steps = 2600, ccw = true, down = false }) => {
      s.spawnAt(x, z, y, 0, 0);
      let stuck = null;
      let i = 0;
      for (; i < steps; i++) {
        if (down ? pl.footY <= target + 0.02 : pl.footY >= target - 0.02) break;
        const dx = pl.pos.x - cx, dz = pl.pos.z - cz;
        const a = Math.atan2(dz, dx);
        const r = Math.hypot(dx, dz);
        // look ahead along the helix at the walking radius and steer at that
        // point: a player follows the curve, they do not hold a tangent
        const da = 0.22 * (ccw ? 1 : -1);
        const tr = Math.max(1.0, Math.min(1.95, r * 0.6 + targetR * 0.4));
        const px = cx + Math.cos(a + da) * tr;
        const pz = cz + Math.sin(a + da) * tr;
        let vx = px - pl.pos.x, vz = pz - pl.pos.z;
        const l = Math.hypot(vx, vz) || 1;
        if (stepOnce({ x: vx / l, z: vz / l }) < 1e-5) {
          if (!stuck) stuck = { x: +pl.pos.x.toFixed(2), z: +pl.pos.z.toFixed(2), foot: +pl.footY.toFixed(2) };
          break;
        }
      }
      pl.keys.KeyW = false;
      const reached = pl.footY >= target - 0.06;

      // step off the winder, radially outward, onto the floor
      let offStuck = null;
      const ox = pl.pos.x - cx, oz = pl.pos.z - cz;
      const oa = Math.atan2(oz, ox);
      for (let j = 0; j < 120; j++) {
        if (stepOnce({ x: Math.cos(oa), z: Math.sin(oa) }) < 1e-5) {
          if (!offStuck) offStuck = { x: +pl.pos.x.toFixed(2), z: +pl.pos.z.toFixed(2), foot: +pl.footY.toFixed(2) };
          break;
        }
        if (Math.hypot(pl.pos.x - cx, pl.pos.z - cz) > 3.3) break;
      }
      pl.keys.KeyW = false;
      return {
        reached, steps: i, stuck, offStuck,
        x: +pl.pos.x.toFixed(2), z: +pl.pos.z.toFixed(2), foot: +pl.footY.toFixed(2),
        level: g.currentLevel()?.id || null, room: g.roomName(g.currentLevel()),
        radius: +Math.hypot(pl.pos.x - cx, pl.pos.z - cz).toFixed(2),
      };
    };

    // straight walk from a start point along a heading
    const walk = ({ x, z, y, yaw, steps = 500, dt = 0.033 }) => {
      s.spawnAt(x, z, y, yaw, 0);
      pl.keys.KeyW = true;
      let stuckAt = null;
      for (let i = 0; i < steps; i++) {
        const bx = pl.pos.x, bz = pl.pos.z;
        pl.update(dt, g);
        g.update(dt);
        if (Math.hypot(pl.pos.x - bx, pl.pos.z - bz) < 1e-5 && !stuckAt) {
          stuckAt = { x: +pl.pos.x.toFixed(2), z: +pl.pos.z.toFixed(2), foot: +pl.footY.toFixed(2) };
          break;
        }
      }
      pl.keys.KeyW = false;
      return {
        x: +pl.pos.x.toFixed(2), z: +pl.pos.z.toFixed(2), foot: +pl.footY.toFixed(2),
        level: g.currentLevel()?.id || null, room: g.roomName(g.currentLevel()), stuckAt,
      };
    };

    const out = {};
    out.gfToF2 = climbTo({ x: -2.75, z: 7.5, y: 0, target: 4.2 });
    out.f2ToF3 = climbTo({ x: -2.75, z: 7.5, y: 4.2, target: 8.0 });
    out.f3ToF4 = climbTo({ x: -2.75, z: 7.5, y: 8.0, target: 11.6 });
    out.f4ToF3 = climbTo({ x: -2.75, z: 7.5, y: 11.6, target: 8.0, ccw: false, down: true });
    out.f3ToF2 = climbTo({ x: -2.75, z: 7.5, y: 8.0, target: 4.2, ccw: false, down: true });
    out.f2ToGF = climbTo({ x: -2.75, z: 7.5, y: 4.2, target: 0, ccw: false, down: true });
    // basement: from the west service hall, north along the stair, and back
    out.gfToB1 = walk({ x: -15.7, z: -5.0, y: 0, yaw: 0, steps: 460 });
    out.b1ToGF = walk({ x: -15.7, z: -10.3, y: -3.4, yaw: Math.PI, steps: 460 });
    // and walking the landing ring around the stairwell instead of into it
    out.landingF2 = walk({ x: -4.6, z: 7.5, y: 4.2, yaw: Math.PI, steps: 160 });
    return out;
  });

  console.log(JSON.stringify(result, null, 1));
  const ok = ['gfToF2', 'f2ToF3', 'f3ToF4', 'f4ToF3', 'f3ToF2', 'f2ToGF'].every((k) => result[k].reached);
  const b1ok = result.gfToB1.foot < -3.3 && result.b1ToGF.foot > -0.1;
  console.log('ALL FLOORS REACHED:', ok, ' BASEMENT BOTH WAYS:', b1ok);
  await browser.close();
  if (!ok || !b1ok) process.exitCode = 2;
})().catch((e) => { console.error(e); process.exit(1); });
