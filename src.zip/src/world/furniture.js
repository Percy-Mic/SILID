// FURNITURE — the mansion's real furniture, modelled in Blender.
//
// The assets come from scripts/build_furniture.py, which builds every piece
// with real joinery: bevelled edges, turned legs, raised door panels, rolled
// sofa arms, an inset sink bowl, a moulded cistern. That geometry is the whole
// point: a wardrobe with panelled doors and a plinth reads as a wardrobe from
// across a dark room, and a textured box does not.
//
// This module owns only three things:
//   1. loading the single GLB and splitting it into per-material geometries,
//   2. the material a piece's faces use (mapped to src/world/materials.js),
//   3. footprints and place-helpers, so props.js can validate and collide them.
//
// Draw calls stay low because props.js merges every placement of every piece on
// a floor into one mesh per material — the same strategy the box furniture
// used. A fully dressed floor is still about a dozen draw calls.

import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { materials } from './materials.js';

const URL = '/assets/models/furniture.glb';

// Blender UVs are metres. Fabric and leather want a finer weave than that, so
// their UVs are scaled up on load; wood stays at one metre of grain per metre.
const UV_SCALE = {
  velvet: 2.2,
  linen: 1.9,
  leather: 1.5,
  paint: 1.0,
  wood: 1.0,
  woodDark: 1.0,
  woodGrey: 1.0,
  marble: 1.0,
  tile: 1.0,
  porcelain: 1.0,
  ironDark: 1.0,
  brass: 1.0,
  iron: 1.0,
  glass: 1.0,
  rust: 1.0,
};

export const furniture = {
  templates: new Map(),
  errors: [],
  tris: 0,
  count: 0,
  loaded: false,
};

// A piece is placeable against a wall only if its model's front faces +Z, which
// the exporter guarantees (Blender's -Y front becomes +Z). These flags are the
// exceptions to "a floor piece is a collider".
export const MOUNTED = new Set(['counter_top', 'hood', 'wall_cabinet', 'shower']);

function templateTriangles(geo) {
  const index = geo.getIndex();
  return index ? index.count / 3 : geo.attributes.position.count / 3;
}

export async function loadFurniture(onProgress) {
  const loader = new GLTFLoader();
  let gltf;
  try {
    gltf = await new Promise((resolve, reject) => {
      loader.load(URL, resolve, (e) => { if (e.total) onProgress?.(e.loaded / e.total); }, reject);
    });
  } catch (err) {
    // Furniture is not the world: if the asset is missing the estate still
    // loads, and the console says exactly which file failed.
    furniture.errors.push('furniture.glb: ' + (err?.message || err));
    console.warn('[furniture] the models did not load:', err?.message || err);
    return furniture;
  }

  gltf.scene.updateMatrixWorld(true);

  for (const child of [...gltf.scene.children]) {
    const name = child.name;
    if (!name) continue;
    const geos = [];
    child.traverse((o) => {
      if (!o.isMesh || !o.geometry) return;
      const geo = o.geometry.clone();
      geo.applyMatrix4(o.matrixWorld);
      // glTF can carry tangents/colours the game never uses; merging requires
      // every geometry to have the same attribute set.
      for (const key of Object.keys(geo.attributes)) {
        if (key !== 'position' && key !== 'normal' && key !== 'uv') geo.deleteAttribute(key);
      }
      if (!geo.attributes.uv) {
        const n = geo.attributes.position.count;
        geo.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(n * 2), 2));
      }
      const src = Array.isArray(o.material) ? o.material[0] : o.material;
      const matName = src?.name || 'wood';
      const key = materials[matName] ? matName : 'wood';
      const s = UV_SCALE[key] || 1;
      if (s !== 1) {
        const uv = geo.attributes.uv;
        for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * s, uv.getY(i) * s);
        uv.needsUpdate = true;
      }
      geo.computeBoundingBox();
      geos.push({ mat: key, geo, tris: templateTriangles(geo) });
    });
    if (!geos.length) continue;

    const box = new THREE.Box3();
    for (const g of geos) box.union(g.geo.boundingBox);
    const tris = geos.reduce((n, g) => n + g.tris, 0);
    furniture.templates.set(name, { name, geos, box, tris });
    furniture.tris += tris;
  }

  furniture.loaded = true;
  furniture.count = furniture.templates.size;
  onProgress?.(1);
  return furniture;
}

export function template(name) {
  return furniture.templates.get(name) || null;
}

// The footprint of a piece after it is turned by rotY, in world axes. Furniture
// is validated against the same room/door/overlap rules as everything else, and
// those rules are axis-aligned, so an axis-aligned box is what they need.
export function footprint(name, x, z, rotY = 0) {
  const t = template(name);
  if (!t) return null;
  const { min, max } = t.box;
  const c = Math.cos(rotY), s = Math.sin(rotY);
  let x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
  for (const px of [min.x, max.x]) {
    for (const pz of [min.z, max.z]) {
      const wx = x + px * c + pz * s;
      const wz = z - px * s + pz * c;
      x0 = Math.min(x0, wx); x1 = Math.max(x1, wx);
      z0 = Math.min(z0, wz); z1 = Math.max(z1, wz);
    }
  }
  return { x0, x1, z0, z1, height: max.y - min.y, minY: min.y, depth: max.z - min.z, width: max.x - min.x };
}

export function disposeFurniture() {
  for (const t of furniture.templates.values()) for (const g of t.geos) g.geo.dispose();
  furniture.templates.clear();
  furniture.loaded = false;
}
